package fdsa.edu.pnu.DTO;

public class PublicationDTO {
}
