/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * <p>
 * This is an automatic generated file. It will be regenerated every time
 * you generate persistence class.
 * <p>
 * Modifying its content may cause the program not work, or your work may lost.
 * <p>
 * Licensee:
 * License Type: Evaluation
 */

/**
 * Licensee: 
 * License Type: Evaluation
 */
package fdsa.edu.pnu.Repository;


import fdsa.edu.pnu.Model.Fonction;
import org.springframework.data.jpa.repository.JpaRepository;


public interface FonctionDAO extends JpaRepository<Fonction, Integer> {
//	public Fonction loadFonctionByORMID(int id) throws PersistentException;
//	public Fonction getFonctionByORMID(int id) throws PersistentException;
//	public Fonction loadFonctionByORMID(int id, org.hibernate.LockMode lockMode) throws PersistentException;
//	public Fonction getFonctionByORMID(int id, org.hibernate.LockMode lockMode) throws PersistentException;
//	public Fonction loadFonctionByORMID(PersistentSession session, int id) throws PersistentException;
//	public Fonction getFonctionByORMID(PersistentSession session, int id) throws PersistentException;
//	public Fonction loadFonctionByORMID(PersistentSession session, int id, org.hibernate.LockMode lockMode) throws PersistentException;
//	public Fonction getFonctionByORMID(PersistentSession session, int id, org.hibernate.LockMode lockMode) throws PersistentException;
//	public Fonction[] listFonctionByQuery(String condition, String orderBy) throws PersistentException;
//	public Fonction[] listFonctionByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public java.util.List queryFonction(String condition, String orderBy) throws PersistentException;
//	public java.util.List queryFonction(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public java.util.Iterator iterateFonctionByQuery(String condition, String orderBy) throws PersistentException;
//	public java.util.Iterator iterateFonctionByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public Fonction[] listFonctionByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException;
//	public Fonction[] listFonctionByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public java.util.List queryFonction(PersistentSession session, String condition, String orderBy) throws PersistentException;
//	public java.util.List queryFonction(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public java.util.Iterator iterateFonctionByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException;
//	public java.util.Iterator iterateFonctionByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public Fonction loadFonctionByQuery(String condition, String orderBy) throws PersistentException;
//	public Fonction loadFonctionByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public Fonction loadFonctionByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException;
//	public Fonction loadFonctionByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public Fonction createFonction();
//	public boolean save(pnu.Fonction fonction) throws PersistentException;
//	public boolean delete(pnu.Fonction fonction) throws PersistentException;
//	public boolean deleteAndDissociate(pnu.Fonction fonction) throws PersistentException;
//	public boolean deleteAndDissociate(pnu.Fonction fonction, org.orm.PersistentSession session) throws PersistentException;
//	public boolean refresh(pnu.Fonction fonction) throws PersistentException;
//	public boolean evict(pnu.Fonction fonction) throws PersistentException;
//	public Fonction loadFonctionByCriteria(FonctionCriteria fonctionCriteria);
//	public Fonction[] listFonctionByCriteria(FonctionCriteria fonctionCriteria);
}
