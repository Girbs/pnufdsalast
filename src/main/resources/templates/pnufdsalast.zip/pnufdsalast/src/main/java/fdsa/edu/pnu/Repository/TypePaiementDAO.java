/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * <p>
 * This is an automatic generated file. It will be regenerated every time
 * you generate persistence class.
 * <p>
 * Modifying its content may cause the program not work, or your work may lost.
 * <p>
 * Licensee:
 * License Type: Evaluation
 */

/**
 * Licensee: 
 * License Type: Evaluation
 */
package fdsa.edu.pnu.Repository;


import fdsa.edu.pnu.Model.TypePaiement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TypePaiementDAO extends JpaRepository<TypePaiement, Integer> {
//	public TypePaiement loadTypePaiementByORMID(int id) throws PersistentException;
//	public TypePaiement getTypePaiementByORMID(int id) throws PersistentException;
//	public TypePaiement loadTypePaiementByORMID(int id, org.hibernate.LockMode lockMode) throws PersistentException;
//	public TypePaiement getTypePaiementByORMID(int id, org.hibernate.LockMode lockMode) throws PersistentException;
//	public TypePaiement loadTypePaiementByORMID(PersistentSession session, int id) throws PersistentException;
//	public TypePaiement getTypePaiementByORMID(PersistentSession session, int id) throws PersistentException;
//	public TypePaiement loadTypePaiementByORMID(PersistentSession session, int id, org.hibernate.LockMode lockMode) throws PersistentException;
//	public TypePaiement getTypePaiementByORMID(PersistentSession session, int id, org.hibernate.LockMode lockMode) throws PersistentException;
//	public TypePaiement[] listTypePaiementByQuery(String condition, String orderBy) throws PersistentException;
//	public TypePaiement[] listTypePaiementByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public java.util.List queryTypePaiement(String condition, String orderBy) throws PersistentException;
//	public java.util.List queryTypePaiement(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public java.util.Iterator iterateTypePaiementByQuery(String condition, String orderBy) throws PersistentException;
//	public java.util.Iterator iterateTypePaiementByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public TypePaiement[] listTypePaiementByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException;
//	public TypePaiement[] listTypePaiementByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public java.util.List queryTypePaiement(PersistentSession session, String condition, String orderBy) throws PersistentException;
//	public java.util.List queryTypePaiement(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public java.util.Iterator iterateTypePaiementByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException;
//	public java.util.Iterator iterateTypePaiementByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public TypePaiement loadTypePaiementByQuery(String condition, String orderBy) throws PersistentException;
//	public TypePaiement loadTypePaiementByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public TypePaiement loadTypePaiementByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException;
//	public TypePaiement loadTypePaiementByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException;
//	public TypePaiement createTypePaiement();
//	public boolean save(pnu.TypePaiement typePaiement) throws PersistentException;
//	public boolean delete(pnu.TypePaiement typePaiement) throws PersistentException;
//	public boolean deleteAndDissociate(pnu.TypePaiement typePaiement) throws PersistentException;
//	public boolean deleteAndDissociate(pnu.TypePaiement typePaiement, org.orm.PersistentSession session) throws PersistentException;
//	public boolean refresh(pnu.TypePaiement typePaiement) throws PersistentException;
//	public boolean evict(pnu.TypePaiement typePaiement) throws PersistentException;
//	public TypePaiement loadTypePaiementByCriteria(TypePaiementCriteria typePaiementCriteria);
//	public TypePaiement[] listTypePaiementByCriteria(TypePaiementCriteria typePaiementCriteria);
}
